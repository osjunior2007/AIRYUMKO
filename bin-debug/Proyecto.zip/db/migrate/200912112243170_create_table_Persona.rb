class CreateTablePersona < ActiveRecord::Migration 
def self.up 
  create_table "Persona", :force => true do |t| 
 t.column :name, :string, :limit => 40
 t.column :last_name, :string, :limit => 40
end 
 end 
 def self.down 
  drop_table "Persona"
  end 
 end 
