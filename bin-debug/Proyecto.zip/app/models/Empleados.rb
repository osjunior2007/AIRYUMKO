class Empleados < ActiveRecord::Base

end