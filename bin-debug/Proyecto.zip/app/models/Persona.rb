class Persona < ActiveRecord::Base

end