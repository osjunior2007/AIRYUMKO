class EmpleadossController < ApplicationController

def list
@Empleadoss = Empleados.find :all
render :json => @Empleadoss.to_json
end



def create
@Empleadoss =Empleados.new(params[:objetos])
if @Empleadoss.save
render :xml => 0 
else
render :xml => 1 
end
end



def delete
@Empleadoss = Empleados.find(params[:id])
if @Empleadoss.destroy
#render :xml => 0 
render :json => @nombre.to_json
else
render :xml => 1 
end
end



def update
@Empleadoss= Empleados.find(params[:objetos][:id])
if @Empleadoss.update_attributes([:objetos])
render :xml => 0 
else
render :xml => 1 
end
end



end