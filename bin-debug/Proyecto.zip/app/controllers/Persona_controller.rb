class PersonasController < ApplicationController

def list
@Personas = Persona.find :all
render :json => @Personas.to_json
end



def create
@Personas =Persona.new(params[:objetos])
if @Personas.save
render :xml => 0 
else
render :xml => 1 
end
end



def delete
@Personas = Persona.find(params[:id])
if @Personas.destroy
#render :xml => 0 
render :json => @nombre.to_json
else
render :xml => 1 
end
end



def update
@Personas= Persona.find(params[:objetos][:id])
if @Personas.update_attributes([:objetos])
render :xml => 0 
else
render :xml => 1 
end
end



end