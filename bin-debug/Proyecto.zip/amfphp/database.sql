CREATE DATABASE /*!32312 IF NOT EXISTS*/`test` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `test`;
CREATE TABLE`Peoples` (
`name` varchar (40) DEFAULT NULL,
`state` varchar (40) DEFAULT NULL,
PRIMARY KEY (`id`) 
)ENGINE=MyISAM AUTO_INCREMENT=40001 DEFAULT CHARSET=latin1;

CREATE TABLE`Productos` (
`nombre` varchar (40) DEFAULT NULL,
`precio` varchar (5) DEFAULT NULL,
`cantidad` varchar (5) DEFAULT NULL,
PRIMARY KEY (`id`) 
)ENGINE=MyISAM AUTO_INCREMENT=40001 DEFAULT CHARSET=latin1;

CREATE TABLE`Salones` (
`nombre` varchar (40) DEFAULT NULL,
`codigo` varchar (6) DEFAULT NULL,
`cantidad_estudiante` varchar (3) DEFAULT NULL,
PRIMARY KEY (`id`) 
)ENGINE=MyISAM AUTO_INCREMENT=40001 DEFAULT CHARSET=latin1;

