<?php

class People extends ActiveRecord\Model
{

 static $table_name = 'People';
}

?>