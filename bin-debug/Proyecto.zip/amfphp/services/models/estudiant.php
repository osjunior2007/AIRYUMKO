<?php

class Estudiant extends ActiveRecord\Model
{

 static $table_name = 'Estudiants';
}

?>