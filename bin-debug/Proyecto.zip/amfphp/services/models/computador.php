<?php

class Computador extends ActiveRecord\Model
{

 static $table_name = 'Computadors';
}

?>