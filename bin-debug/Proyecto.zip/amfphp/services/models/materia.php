<?php

class Materia extends ActiveRecord\Model
{

 static $table_name = 'Materias';
}

?>