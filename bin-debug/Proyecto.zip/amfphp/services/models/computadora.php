<?php

class Computadora extends ActiveRecord\Model
{

 static $table_name = 'Computadoras';
}

?>