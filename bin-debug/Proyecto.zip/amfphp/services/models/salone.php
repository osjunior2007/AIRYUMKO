<?php

class Salone extends ActiveRecord\Model
{

 static $table_name = 'Salone';
}

?>