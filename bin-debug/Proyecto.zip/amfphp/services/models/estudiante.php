<?php

class Estudiante extends ActiveRecord\Model
{

 static $table_name = 'Estudiantes';
}

?>