<?php

class Padr extends ActiveRecord\Model
{

 static $table_name = 'Padrs';
}

?>