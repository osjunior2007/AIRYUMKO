<?php

class Account extends ActiveRecord\Model
{

 static $table_name = 'Accounts';
}

?>