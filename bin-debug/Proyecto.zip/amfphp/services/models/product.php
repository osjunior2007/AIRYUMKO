<?php

class Product extends ActiveRecord\Model
{

 static $table_name = 'Products';
}

?>