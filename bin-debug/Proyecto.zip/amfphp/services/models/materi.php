<?php

class Materi extends ActiveRecord\Model
{

 static $table_name = 'Materis';
}

?>