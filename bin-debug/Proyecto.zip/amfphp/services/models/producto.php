<?php

class Producto extends ActiveRecord\Model
{

 static $table_name = 'Producto';
}

?>