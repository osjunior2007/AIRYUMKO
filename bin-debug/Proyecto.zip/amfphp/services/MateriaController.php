<?php
include("lib/database.php");
class MateriaController {

function index() {
 return amf(Materi::find(all));
}



 function create($param) {
$Materi = new Materi($param);
if ($Materi->is_valid()){
$Materi->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$Materi = Materi::find($param[id]);
if ($Materi->is_valid()){
$Materi->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$Materi = Materi::find_by_id($param[id]);
if ($Materi->is_valid()){
$Materi->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
