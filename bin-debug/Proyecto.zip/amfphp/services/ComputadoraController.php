<?php
include("lib/database.php");
class ComputadoraController {

function index() {
 return amf(Computador::find(all));
}



 function create($param) {
$Computador = new Computador($param);
if ($Computador->is_valid()){
$Computador->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$Computador = Computador::find($param[id]);
if ($Computador->is_valid()){
$Computador->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$Computador = Computador::find_by_id($param[id]);
if ($Computador->is_valid()){
$Computador->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
