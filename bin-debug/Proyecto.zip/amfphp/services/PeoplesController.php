<?php
include("lib/database.php");
class PeoplesController {

function index() {
 return amf(People::find(all));
}



 function create($param) {
$People = new People($param);
if ($People->is_valid()){
$People->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$People = People::find($param[id]);
if ($People->is_valid()){
$People->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$People = People::find_by_id($param[id]);
if ($People->is_valid()){
$People->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
