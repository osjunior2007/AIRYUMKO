<?php
include("lib/database.php");
class EstudiantesController {

function index() {
 return amf(Estudiante::find(all));
}



 function create($param) {
$Estudiante = new Estudiante($param);
if ($Estudiante->is_valid()){
$Estudiante->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$Estudiante = Estudiante::find($param[id]);
if ($Estudiante->is_valid()){
$Estudiante->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$Estudiante = Estudiante::find_by_id($param[id]);
if ($Estudiante->is_valid()){
$Estudiante->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
