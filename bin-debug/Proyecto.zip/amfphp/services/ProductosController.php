<?php
include("lib/database.php");
class ProductosController {

function index() {
 return amf(Producto::find(all));
}



 function create($param) {
$Producto = new Producto($param);
if ($Producto->is_valid()){
$Producto->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$Producto = Producto::find($param[id]);
if ($Producto->is_valid()){
$Producto->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$Producto = Producto::find_by_id($param[id]);
if ($Producto->is_valid()){
$Producto->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
