<?php
include("lib/database.php");
class PadreController {

function index() {
 return amf(Padr::find(all));
}



 function create($param) {
$Padr = new Padr($param);
if ($Padr->is_valid()){
$Padr->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$Padr = Padr::find($param[id]);
if ($Padr->is_valid()){
$Padr->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$Padr = Padr::find_by_id($param[id]);
if ($Padr->is_valid()){
$Padr->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
