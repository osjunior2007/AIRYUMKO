<?php
include("lib/database.php");
class AccountsController {

function index() {
 return amf(Account::find(all));
}



 function create($param) {
$Account = new Account($param);
if ($Account->is_valid()){
$Account->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$Account = Account::find($param[id]);
if ($Account->is_valid()){
$Account->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$Account = Account::find_by_id($param[id]);
if ($Account->is_valid()){
$Account->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
