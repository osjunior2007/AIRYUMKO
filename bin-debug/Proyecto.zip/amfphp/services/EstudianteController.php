<?php
include("lib/database.php");
class EstudianteController {

function index() {
 return amf(Estudiant::find(all));
}



 function create($param) {
$Estudiant = new Estudiant($param);
if ($Estudiant->is_valid()){
$Estudiant->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$Estudiant = Estudiant::find($param[id]);
if ($Estudiant->is_valid()){
$Estudiant->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$Estudiant = Estudiant::find_by_id($param[id]);
if ($Estudiant->is_valid()){
$Estudiant->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
