<?php
include("lib/database.php");
class BuildsController {

function index() {
 return amf(Build::find(all));
}



 function create($param) {
$Build = new Build($param);
if ($Build->is_valid()){
$Build->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$Build = Build::find($param[id]);
if ($Build->is_valid()){
$Build->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$Build = Build::find_by_id($param[id]);
if ($Build->is_valid()){
$Build->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
