<?php 
 require_once ('ActiveRecord.php');

ActiveRecord\Config::initialize(function($cfg)
{
 $cfg->set_model_directory('models');
$cfg->set_connections(array('development' => 'mysql://root:@127.0.0.1/myescuela'));

});

 function amf($sMessage) {
  $cant=0;
  $array = array();
  foreach($sMessage as $key )
    {
  $array[$cant]=array($key->attributes());
  $cant++;
     }
    return $array;
       }


    ?>
