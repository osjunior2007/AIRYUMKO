<?php
include("lib/database.php");
class ProductsController {

function index() {
 return amf(Product::find(all));
}



 function create($param) {
$Product = new Product($param);
if ($Product->is_valid()){
$Product->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$Product = Product::find($param[id]);
if ($Product->is_valid()){
$Product->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$Product = Product::find_by_id($param[id]);
if ($Product->is_valid()){
$Product->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
