<?php
include("lib/database.php");
class MateriasController {

 function index($param) {
 if ($param[type]=="all") {
   return amf(Materia::find(all));
 }else{
   return amf(Materia::find(all,array('select' => " 'false' as options,nombre,codigo")));
 }
}



 function create($param) {
$Materia = new Materia($param);
if ($Materia->is_valid()){
$Materia->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$Materia = Materia::find($param[id]);
if ($Materia->is_valid()){
$Materia->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$Materia = Materia::find_by_id($param[id]);
if ($Materia->is_valid()){
$Materia->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
