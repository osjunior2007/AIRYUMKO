<?php
include("lib/database.php");
class SalonesController {

function index() {
 return amf(Salone::find(all));
}



 function create($param) {
$Salone = new Salone($param);
if ($Salone->is_valid()){
$Salone->save();
return 0;}else{
return 1; 
}
}


function destroy ($param) {
$Salone = Salone::find($param[id]);
if ($Salone->is_valid()){
$Salone->delete();
return 0; 
}else{
return  1; 
}
}



 function update($param) {
$Salone = Salone::find_by_id($param[id]);
if ($Salone->is_valid()){
$Salone->update_attributes($param);
return 0; 
}else{
return 1; 
}
}



}
